# automate-aws
Automating AWS using python

#01-webotron
A script that will start a session with s3 resource

Currently has following features:
1. List buckets in s3
2. List all objects in a bucket
3. Apply a policy to bucket and create a bucket
4. Upload files to s3 bucket
5. profile specified

#02-notifon
A script to notify on slack users when changes made to AWS Account using CloudWatch Events

##Features
Currently has following features
